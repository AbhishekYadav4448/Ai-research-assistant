# AI Research Assistant

A lightweight full‑stack app that fetches web pages (respecting `robots.txt`), extracts readable text, and synthesizes findings with the **Gemini** API — returning an overall summary, per‑source key points, FAQs, quiz questions, and citations.

> **Stack**: Flask (Python) · HTML + CSS (no frameworks) · Vanilla JS · requests · readability-lxml · BeautifulSoup · lxml · CORS · python-dotenv

![Screenshot placeholder](./docs/screenshot.png)

## Features
- **Two input modes**: paste up to 5 URLs, or search by topic (if Google CSE is configured)
- **Robots-aware**: checks `robots.txt` before fetching
- **Readable extraction**: `readability-lxml` + BeautifulSoup fallback; removes scripts/nav
- **Server-side LLM calls**: all Gemini API calls are from the backend — no secrets in the frontend
- **Structured results**: overall summary, per‑source key points & quotes, FAQs, quiz, citations
- **Clean UI**: semantic HTML, responsive CSS, minimal JS; copy‑to‑clipboard for sections
- **Defensive**: retries, timeouts, graceful errors, robust JSON parsing from LLM

## Local Setup
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env  # then edit and set GEMINI_API_KEY
# (Optional) Set SEARCH_PROVIDER=google_cse with GOOGLE_CSE_ID and GOOGLE_API_KEY to enable topic search
flask --app app.py run --debug --port 8000
```

### Environment
- `GEMINI_API_KEY` (**required**)
- `GEMINI_MODEL` (default: `gemini-1.5-flash`, fallback: `gemini-pro`)
- `SEARCH_PROVIDER` (optional: `google_cse`)
- `GOOGLE_CSE_ID`, `GOOGLE_API_KEY` (optional; needed for topic search)
- `MAX_SOURCES` (default: `5`)
- `PORT` (default: `8000`)

## Usage
### URLs Mode
1. Open the app, select **Paste URLs**
2. Paste 1–5 URLs (one per line)
3. Click **Research**
4. Review the overall summary, per‑source key points & quotes, FAQs, quiz, and citations

### Topic Mode (if enabled)
1. Configure Google CSE keys (`SEARCH_PROVIDER=google_cse`, `GOOGLE_CSE_ID`, `GOOGLE_API_KEY`)
2. Select **Search Topic** and enter a topic
3. The app searches, fetches top results, extracts, summarizes, and synthesizes

## Notes
- **Rate limits & token sizes**: The app approximates token counts by text length. Keep inputs concise to avoid long latencies or model limits.
- **Privacy**: Content you submit is sent to Google’s Generative Language API for processing. Avoid sensitive data.
- **Legal**: The app respects `robots.txt` and aims for fair use. Always review site terms before large-scale extraction.

## Deployment
- Any Python-friendly host works (Render, Railway, Fly.io, Heroku, etc.)
- Example `gunicorn` command:
  ```bash
  gunicorn -w 2 -k gthread -b 0.0.0.0:${PORT:-8000} app:app
  ```
- Ensure environment variables are set (see `.env.example`).

## Troubleshooting
- **Topic tab disabled**: Set `SEARCH_PROVIDER=google_cse` and provide `GOOGLE_CSE_ID` + `GOOGLE_API_KEY`
- **Blocked by robots.txt**: Some sites disallow scraping; try different sources
- **Empty extraction**: Pages heavy in JavaScript or behind paywalls may not render for `requests`
- **Gemini errors**: Check `GEMINI_API_KEY`, model name, and network egress. The app retries with a fallback model when possible.

## License
[MIT](./LICENSE)
