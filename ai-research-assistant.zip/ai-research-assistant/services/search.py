import os
from typing import List, Dict

import requests

SEARCH_PROVIDER = os.getenv('SEARCH_PROVIDER', '').lower()
GOOGLE_CSE_ID = os.getenv('GOOGLE_CSE_ID')
GOOGLE_API_KEY = os.getenv('GOOGLE_API_KEY')

class SearchDisabledError(Exception):
    pass

def _configured() -> bool:
    return SEARCH_PROVIDER == 'google_cse' and bool(GOOGLE_CSE_ID) and bool(GOOGLE_API_KEY)

def search(query: str, max_results: int = 5) -> List[Dict]:
    if not _configured():
        raise SearchDisabledError('Search is disabled. Set SEARCH_PROVIDER=google_cse with GOOGLE_CSE_ID and GOOGLE_API_KEY.')

    url = 'https://www.googleapis.com/customsearch/v1'
    params = {
        'q': query,
        'cx': GOOGLE_CSE_ID,
        'key': GOOGLE_API_KEY,
        'num': min(10, max(1, max_results * 2)),
        'safe': 'active'
    }
    resp = requests.get(url, params=params, timeout=20)
    resp.raise_for_status()
    data = resp.json()

    items = []
    for itm in (data.get('items') or []):
        link = itm.get('link')
        title = itm.get('title') or ''
        if not link:
            continue
        l = link.lower()
        if any(l.endswith(ext) for ext in ('.pdf', '.ppt', '.pptx', '.xls', '.xlsx', '.doc', '.docx')):
            continue
        if any(k in l for k in ('/login', '/signin', '/account', 'auth=')):
            continue
        try:
            from urllib.parse import urlparse
            p = urlparse(link)
            if not p.path or p.path == '/':
                continue
        except Exception:
            pass

        items.append({'url': link, 'title': title})
        if len(items) >= max_results:
            break

    return items
