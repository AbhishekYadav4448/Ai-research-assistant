import time
import requests
from readability import Document
from bs4 import BeautifulSoup

from utils.text import clean_text
from utils.robots import is_allowed

HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
        '(KHTML, like Gecko) Chrome/122.0 Safari/537.36'
    )
}

def is_allowed_by_robots(url: str) -> bool:
    try:
        return is_allowed(url, HEADERS['User-Agent'])
    except Exception:
        return False

def fetch_html(url: str, timeout: int = 12, retries: int = 2, backoff: float = 0.75) -> str:
    last_exc = None
    for i in range(retries + 1):
        try:
            resp = requests.get(url, headers=HEADERS, timeout=timeout)
            if resp.status_code == 200 and 'text/html' in resp.headers.get('Content-Type', ''):
                return resp.text
            elif resp.status_code in (301, 302, 303, 307, 308):
                return resp.text
            else:
                last_exc = Exception(f"HTTP {resp.status_code}")
        except requests.RequestException as e:
            last_exc = e
        time.sleep(backoff * (i + 1))
    if last_exc:
        raise last_exc
    return ''

def _strip_unwanted(soup: BeautifulSoup):
    for tag in soup(['script', 'style', 'noscript', 'nav', 'header', 'footer', 'aside', 'form']):
        tag.decompose()

def extract_main_content(html: str, url: str):
    doc = Document(html)
    title = doc.short_title() or ''
    summary_html = doc.summary(html_partial=True)
    soup = BeautifulSoup(summary_html, 'lxml')
    _strip_unwanted(soup)
    text = clean_text(soup.get_text('
'))

    if len(text) < 400:
        soup_full = BeautifulSoup(html, 'lxml')
        _strip_unwanted(soup_full)
        text = clean_text(soup_full.get_text('
'))
        if not title and soup_full.title:
            title = clean_text(soup_full.title.get_text())

    return {'url': url, 'title': title or url, 'text': text}
