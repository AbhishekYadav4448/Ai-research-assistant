from typing import List, Dict, Any

from utils.text import chunk_text
from services.gemini import summarize_source as llm_summarize_source, synthesize_across_sources as llm_synthesize

TARGET_CHARS = 6000

def _merge_source_chunks(chunks_outputs: List[Dict[str, Any]], fallback_title: str) -> Dict[str, Any]:
    title = fallback_title
    summaries = []
    key_points = []
    quotes = []
    tokens_in = 0
    tokens_out = 0
    model_name = None

    for c in chunks_outputs:
        if not c:
            continue
        if not title:
            title = c.get('title') or fallback_title
        if c.get('summary'):
            summaries.append(c['summary'])
        for kp in c.get('key_points', [])[:6]:
            if kp not in key_points:
                key_points.append(kp)
        for qt in c.get('notable_quotes', [])[:3]:
            if qt not in quotes:
                quotes.append(qt)
        stats = (c.get('_stats') or {}).get('tokens') or {}
        tokens_in += int(stats.get('input', 0))
        tokens_out += int(stats.get('output', 0))
        model_name = (c.get('_stats') or {}).get('model', model_name)

    merged_summary = ' '.join(summaries)[:1200]
    return {
        'title': title or '',
        'summary': merged_summary,
        'key_points': key_points[:6],
        'notable_quotes': quotes[:3],
        '_stats': {'tokens': {'input': tokens_in, 'output': tokens_out}, 'model': model_name}
    }

def build_research_response(topic: str, sources: List[Dict[str, str]], model_name: str) -> Dict[str, Any]:
    per_source_results: List[Dict[str, Any]] = []

    for src in sources:
        text = src.get('text', '')
        url = src.get('url')
        title = src.get('title') or url
        if not text:
            continue
        chunks = chunk_text(text, target_size=TARGET_CHARS)
        chunk_outputs = []
        for ch in chunks:
            out = llm_summarize_source(text=ch, url=url, title=title, model=model_name)
            chunk_outputs.append(out)
        merged = _merge_source_chunks(chunk_outputs, fallback_title=title)
        merged['url'] = url
        per_source_results.append(merged)

    synthesis = llm_synthesize(topic=topic, items=[{
        'url': item.get('url'),
        'title': item.get('title'),
        'summary': item.get('summary'),
        'key_points': item.get('key_points'),
        'notable_quotes': item.get('notable_quotes')
    } for item in per_source_results], model=model_name)

    model_used = (synthesis.get('_stats') or {}).get('model') or model_name
    tokens_in = (synthesis.get('_stats') or {}).get('tokens', {}).get('input', 0)
    tokens_out = (synthesis.get('_stats') or {}).get('tokens', {}).get('output', 0)

    for item in per_source_results:
        t = (item.get('_stats') or {}).get('tokens', {})
        tokens_in += int(t.get('input', 0))
        tokens_out += int(t.get('output', 0))

    final = {
        'topic': topic,
        'overall_summary': synthesis.get('overall_summary', ''),
        'sources': [{
            'url': it.get('url'),
            'title': it.get('title'),
            'summary': it.get('summary'),
            'key_points': it.get('key_points'),
            'notable_quotes': it.get('notable_quotes')
        } for it in per_source_results],
        'faqs': synthesis.get('faqs', []),
        'quiz': synthesis.get('quiz', []),
        'citations': synthesis.get('citations', []),
        'model': {'name': model_used, 'tokens_used': {'input': int(tokens_in), 'output': int(tokens_out)}},
        'confidence': float(synthesis.get('confidence', 0.7))
    }

    return final
