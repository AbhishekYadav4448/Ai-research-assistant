import os
import json
from typing import Dict, Any, List

import requests

from utils.text import safe_json_loads, truncate_chars

GEMINI_API_KEY = os.getenv('GEMINI_API_KEY')
DEFAULT_MODEL = os.getenv('GEMINI_MODEL', 'gemini-1.5-flash')
FALLBACK_MODEL = 'gemini-pro'

API_BASE = 'https://generativelanguage.googleapis.com/v1beta'

HEADERS = {
    'Content-Type': 'application/json'
}

class GeminiError(Exception):
    pass


def _generate_content(model: str, prompt: str) -> str:
    if not GEMINI_API_KEY:
        raise GeminiError('GEMINI_API_KEY is not configured.')
    model = model or DEFAULT_MODEL
    endpoint = f"{API_BASE}/models/{model}:generateContent?key={GEMINI_API_KEY}"
    payload = {
        "contents": [
            {
                "role": "user",
                "parts": [{"text": prompt}]
            }
        ],
        "generationConfig": {
            "temperature": 0.1,
            "topP": 0.9,
            "topK": 40
        }
    }
    try:
        resp = requests.post(endpoint, headers=HEADERS, data=json.dumps(payload), timeout=60)
        if resp.status_code >= 400:
            # Retry once with fallback model if configured
            if model != FALLBACK_MODEL and FALLBACK_MODEL:
                fb_endpoint = f"{API_BASE}/models/{FALLBACK_MODEL}:generateContent?key={GEMINI_API_KEY}"
                fb_resp = requests.post(fb_endpoint, headers=HEADERS, data=json.dumps(payload), timeout=60)
                fb_resp.raise_for_status()
                data = fb_resp.json()
            else:
                resp.raise_for_status()
                data = resp.json()
        else:
            data = resp.json()
    except requests.RequestException as e:
        raise GeminiError(f"Gemini API request failed: {e}")

    # Extract text
    try:
        candidates = data.get('candidates', [])
        content = candidates[0]['content']['parts'][0]['text'] if candidates else ''
        return content
    except Exception:
        # Fallback: try to find any text
        content = ''
        if isinstance(data, dict):
            content = json.dumps(data)
        return content


def _approx_tokens(s: str) -> int:
    return max(1, int(len(s) / 4))


def summarize_source(text: str, url: str, title: str = '', model: str = None) -> Dict[str, Any]:
    """Summarize a single source chunk via Gemini with deterministic JSON output."""
    chunk_preview = truncate_chars(text, 12000)
    prompt = (
        "You are a precise research summarizer.
"
        "Return STRICT JSON only. No prose.
"
        "Schema:
"
        "{
  "title": "string",
  "summary": "string",
  "key_points": ["string", "..."],
  "notable_quotes": ["string", "..."]
}

"
        "Instructions:
"
        "- Summarize the source neutrally in <= 180 words.
"
        "- Extract 4–6 key points (factual, concise).
"
        "- Pull 1–3 short notable quotes if present (verbatim, no fabrication).
"
        "- If content is very short or mostly navigation, return minimal fields.
"
        "- Never invent facts. If unsure, omit.
"
        "- Output must be valid JSON, no trailing commas.

"
        f"Context:
URL: {url}
Title: {title}
Content (may be truncated):
{chunk_preview}
"
    )

    output_text = _generate_content(model or DEFAULT_MODEL, prompt)

    data = safe_json_loads(output_text) or {}
    tokens = {
        'input': _approx_tokens(prompt),
        'output': _approx_tokens(output_text)
    }
    data.setdefault('title', title or '')
    data.setdefault('summary', '')
    data.setdefault('key_points', [])
    data.setdefault('notable_quotes', [])
    data['_stats'] = {'tokens': tokens, 'model': model or DEFAULT_MODEL}
    return data


def synthesize_across_sources(topic: str, items: List[Dict[str, Any]], model: str = None) -> Dict[str, Any]:
    per_source_json = json.dumps(items, ensure_ascii=False)
    prompt = (
        "You are an expert synthesis engine.
"
        "Return STRICT JSON only. No prose.
"
        "Schema:
"
        "{
  "overall_summary": "string",
  "faqs": [{"q":"string","a":"string"}],
  "quiz": [{"question":"string","options":["A","B","C","D"],"answerIndex":0}],
  "citations": [{"title":"string","url":"string"}],
  "confidence": 0.0
}

"
        "Instructions:
"
        "- Produce an accurate, non-redundant synthesis across all sources.
"
        "- overall_summary: <= 250 words, balanced, no speculation.
"
        "- faqs: 4–6 common questions with concise answers.
"
        "- quiz: 3–5 MCQs with 4 options each; set answerIndex (0–3).
"
        "- citations: include all usable sources with title and URL.
"
        "- confidence: 0.55–0.95 based on agreement between sources and clarity.
"
        "- Never hallucinate. If sources conflict, state balanced view.

"
        f"Inputs:
Topic: {topic}
Per-source items (JSON array):
{per_source_json}
"
    )

    output_text = _generate_content(model or DEFAULT_MODEL, prompt)
    data = safe_json_loads(output_text) or {}

    data.setdefault('overall_summary', '')
    data.setdefault('faqs', [])
    data.setdefault('quiz', [])
    data.setdefault('citations', [])
    try:
        conf = float(data.get('confidence', 0.7))
    except Exception:
        conf = 0.7
    data['confidence'] = max(0.0, min(1.0, conf))

    tokens = {
        'input': _approx_tokens(prompt),
        'output': _approx_tokens(output_text)
    }
    data['_stats'] = {'tokens': tokens, 'model': model or DEFAULT_MODEL}

    return data
