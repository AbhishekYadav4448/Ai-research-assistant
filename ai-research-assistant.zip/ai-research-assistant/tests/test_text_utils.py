import json
from utils.text import chunk_text, safe_json_loads, truncate_chars


def test_chunk_text_basic():
    text = 'A' * 15000
    chunks = chunk_text(text, target_size=6000, overlap=400)
    # Expect 3 chunks roughly
    assert len(chunks) == 3
    assert len(chunks[0]) <= 6000
    assert chunks[1][:10] == chunks[0][-400:-390]


def test_truncate_chars():
    s = 'hello world'
    assert truncate_chars(s, 50) == s
    assert truncate_chars(s, 5) == 'he...'


def test_safe_json_loads_repairs():
    j = """
```json
{
  "a": 1,
  "b": [
    2,
    3,
  ],
}
```
"""
    data = safe_json_loads(j)
    assert isinstance(data, dict)
    assert data['a'] == 1
    assert data['b'] == [2,3]
