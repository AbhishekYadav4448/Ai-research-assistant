(function(){
  const cfg = (window.__APP_CONFIG__ || {});
  const searchEnabled = !!cfg.searchEnabled;

  const tabUrls = document.getElementById('tab-urls');
  const tabTopic = document.getElementById('tab-topic');
  const panelUrls = document.getElementById('panel-urls');
  const panelTopic = document.getElementById('panel-topic');
  const btnResearch = document.getElementById('btn-research');
  const loader = document.getElementById('loader');
  const results = document.getElementById('results');

  if (!searchEnabled) {
    tabTopic.disabled = true;
    tabTopic.title = 'Topic search disabled (server not configured)';
  }

  function activate(tab){
    [tabUrls, tabTopic].forEach(b=>b.classList.remove('active'));
    [panelUrls, panelTopic].forEach(p=>p.style.display='none');
    tab.classList.add('active');
    if (tab === tabUrls) panelUrls.style.display='block';
    else panelTopic.style.display='block';
  }
  activate(tabUrls);

  tabUrls.addEventListener('click', ()=>activate(tabUrls));
  tabTopic.addEventListener('click', ()=>activate(tabTopic));

  function setLoading(v){ loader.style.display = v ? 'inline-block' : 'none'; btnResearch.disabled = v; }

  function copyText(text){
    navigator.clipboard.writeText(text).then(()=>{
      alert('Copied to clipboard');
    }, ()=>{
      alert('Failed to copy');
    });
  }

  function el(tag, attrs={}, children=[]) {
    const e = document.createElement(tag);
    Object.entries(attrs).forEach(([k,v])=>{
      if (k === 'class') e.className = v; else if (k==='text') e.textContent = v; else e.setAttribute(k,v);
    });
    children.forEach(c=>{ if (typeof c === 'string') e.appendChild(document.createTextNode(c)); else e.appendChild(c); });
    return e;
  }

  function renderResults(data){
    results.innerHTML = '';

    if (data.error){
      results.appendChild(el('div', {class:'card'}, [ el('strong', {text:'Error: '}), document.createTextNode(data.error) ]));
      return;
    }

    const summaryCard = el('div', {class:'card'});
    const h3 = el('h3', {text:'Overall Summary'});
    const pre = el('pre', {text: data.overall_summary || ''});
    const copy = el('button', {class:'secondary copy-btn'}, [document.createTextNode('Copy')]);
    copy.addEventListener('click', ()=>copyText(data.overall_summary || ''));
    summaryCard.appendChild(h3); summaryCard.appendChild(pre); summaryCard.appendChild(copy);
    results.appendChild(summaryCard);

    // Sources grid
    const sourcesCard = el('div', {class:'card'});
    sourcesCard.appendChild(el('h3', {text:'Sources'}));
    const grid = el('div', {class:'grid'});
    (data.sources || []).forEach(s=>{
      const card = el('div', {class:'card source-card'});
      card.appendChild(el('h4', {text: s.title || s.url}));
      card.appendChild(el('a', {href: s.url, target: '_blank', rel: 'noopener', text: s.url}));
      if (Array.isArray(s.key_points) && s.key_points.length){
        const ul = el('ul');
        s.key_points.forEach(kp=> ul.appendChild(el('li', {text: kp})) );
        card.appendChild(ul);
      }
      if (s.summary){
        const pre = el('pre', {text: s.summary});
        card.appendChild(pre);
      }
      if (Array.isArray(s.notable_quotes) && s.notable_quotes.length){
        const quotes = el('div');
        quotes.appendChild(el('strong', {text:'Notable quotes:'}));
        s.notable_quotes.forEach(q=> quotes.appendChild(el('blockquote', {text:q})) );
        card.appendChild(quotes);
      }
      grid.appendChild(card);
    });
    sourcesCard.appendChild(grid);
    results.appendChild(sourcesCard);

    // FAQs
    const faqCard = el('div', {class:'card'});
    faqCard.appendChild(el('h3', {text:'FAQs'}));
    const acc = el('div');
    (data.faqs || []).forEach(f=>{
      const item = el('div', {class:'accordion-item'});
      const details = el('details');
      const summary = el('summary', {text: f.q});
      const ans = el('p', {text: f.a});
      details.appendChild(summary); details.appendChild(ans);
      item.appendChild(details); acc.appendChild(item);
    });
    faqCard.appendChild(acc);
    results.appendChild(faqCard);

    // Quiz
    const quizCard = el('div', {class:'card quiz'});
    quizCard.appendChild(el('h3', {text:'Quiz'}));
    (data.quiz || []).forEach((q,i)=>{
      const wrap = el('div');
      wrap.appendChild(el('div', {class:'question', text: `${i+1}. ${q.question}`}));
      const ul = el('ul', {class:'options'});
      (q.options || []).forEach(opt=> ul.appendChild(el('li', {text: opt})) );
      const ans = el('div', {class:'answer', text: `Answer: ${String.fromCharCode(65 + (q.answerIndex||0))}`});
      wrap.appendChild(ul); wrap.appendChild(ans);
      quizCard.appendChild(wrap);
    });
    results.appendChild(quizCard);

    // Citations
    const citCard = el('div', {class:'card'});
    citCard.appendChild(el('h3', {text:'Citations'}));
    const ul = el('ul');
    (data.citations || []).forEach(c=>{
      const li = el('li');
      const a = el('a', {href: c.url, target:'_blank', rel:'noopener', text: c.title || c.url});
      li.appendChild(a); ul.appendChild(li);
    });
    citCard.appendChild(ul);
    results.appendChild(citCard);

    // Model meta
    const meta = el('div', {class:'card'});
    meta.appendChild(el('h3', {text: 'Model & Usage'}));
    meta.appendChild(el('div', {text: `Model: ${((data.model||{}).name)||'n/a'}`}));
    const tu = (data.model||{}).tokens_used || {input:0, output:0};
    meta.appendChild(el('div', {text: `Approx tokens — input: ${tu.input}, output: ${tu.output}`}));
    meta.appendChild(el('div', {text: `Confidence: ${data.confidence}`}));
    results.appendChild(meta);
  }

  btnResearch.addEventListener('click', async ()=>{
    setLoading(true);
    results.innerHTML = '';

    const mode = tabUrls.classList.contains('active') ? 'urls' : 'topic';
    let body = { mode };
    if (mode === 'urls'){
      const text = document.getElementById('urls').value.trim();
      const urls = text.split(/
+/).map(s=>s.trim()).filter(Boolean).slice(0, 5);
      body.urls = urls;
      if (!urls.length) {
        setLoading(false);
        renderResults({error:'Please paste 1-5 URLs.'});
        return;
      }
    } else {
      const topic = document.getElementById('topic').value.trim();
      body.topic = topic;
      if (!topic){
        setLoading(false);
        renderResults({error:'Please enter a topic.'});
        return;
      }
    }

    try{
      const resp = await fetch('/api/research', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body)});
      const data = await resp.json();
      if (!resp.ok){ renderResults(data); }
      else { renderResults(data); }
    }catch(err){
      renderResults({error:'Network error. Please try again.'});
    } finally {
      setLoading(false);
    }
  });
})();
