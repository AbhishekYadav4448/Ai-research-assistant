import json
import re
from typing import List

def clean_text(text: str) -> str:
    if not text:
        return ''
    text = re.sub(r'
?', '
', text)
    text = re.sub(r'	+', ' ', text)
    text = re.sub(r'
{3,}', '

', text)
    lines = [re.sub(r'\s+', ' ', ln).strip() for ln in text.split('
')]
    text = '
'.join([ln for ln in lines if ln])
    return text.strip()

def truncate_chars(text: str, max_len: int) -> str:
    if text is None:
        return ''
    if len(text) <= max_len:
        return text
    return text[:max(0, max_len - 3)] + '...'

def chunk_text(text: str, target_size: int = 6000, overlap: int = 400) -> List[str]:
    text = text or ''
    if len(text) <= target_size:
        return [text]
    chunks = []
    start = 0
    n = len(text)
    while start < n:
        end = min(n, start + target_size)
        chunk = text[start:end]
        chunks.append(chunk)
        if end == n:
            break
        start = end - overlap
        if start < 0:
            start = 0
    return chunks

def _strip_code_fences(s: str) -> str:
    s = s.strip()
    s = re.sub(r'^```[a-zA-Z]*
', '', s)
    s = re.sub(r'
```$', '', s)
    return s.strip()

def _remove_trailing_commas(s: str) -> str:
    s = re.sub(r',\s*(\]|\})', r'', s)
    return s

def safe_json_loads(s: str):
    if not isinstance(s, str) or not s.strip():
        return None
    try:
        return json.loads(s)
    except Exception:
        pass
    s2 = _strip_code_fences(s)
    s2 = s2.strip()
    try:
        return json.loads(s2)
    except Exception:
        pass
    s3 = _remove_trailing_commas(s2)
    try:
        return json.loads(s3)
    except Exception:
        return None
