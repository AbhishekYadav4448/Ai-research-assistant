import threading
from urllib.parse import urlparse
from urllib import robotparser

_parser_cache = {}
_lock = threading.Lock()

def _get_base(url: str) -> str:
    p = urlparse(url)
    return f"{p.scheme}://{p.netloc}"

def get_parser(base_url: str) -> robotparser.RobotFileParser:
    with _lock:
        if base_url in _parser_cache:
            return _parser_cache[base_url]
        rp = robotparser.RobotFileParser()
        rp.set_url(base_url.rstrip('/') + '/robots.txt')
        try:
            rp.read()
        except Exception:
            pass
        _parser_cache[base_url] = rp
        return rp

def is_allowed(url: str, user_agent: str) -> bool:
    base = _get_base(url)
    rp = get_parser(base)
    try:
        return bool(rp.can_fetch(user_agent, url))
    except Exception:
        return False
