from flask import jsonify

def json_error(message: str, status: int = 400):
    return jsonify({'error': message, 'status': status}), status
