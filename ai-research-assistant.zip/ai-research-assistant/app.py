import os
import json
import logging
from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
from dotenv import load_dotenv

from services import search as search_service
from services import scraper as scraper_service
from services import summarize as summarize_service
from utils.http import json_error

# Load environment variables
load_dotenv()

app = Flask(__name__, static_folder='static', template_folder='templates')
# Enable CORS only for API routes
CORS(app, resources={r"/api/*": {"origins": "*"}})

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Configuration
GEMINI_MODEL = os.getenv('GEMINI_MODEL', 'gemini-1.5-flash')
MAX_SOURCES = int(os.getenv('MAX_SOURCES', '5'))
PORT = int(os.getenv('PORT', '8000'))
SEARCH_PROVIDER = os.getenv('SEARCH_PROVIDER')
GOOGLE_CSE_ID = os.getenv('GOOGLE_CSE_ID')
GOOGLE_API_KEY = os.getenv('GOOGLE_API_KEY')
SEARCH_ENABLED = (
    (SEARCH_PROVIDER or '').lower() == 'google_cse' and bool(GOOGLE_CSE_ID) and bool(GOOGLE_API_KEY)
)

@app.get('/')
def index():
    """Render the main page with a flag indicating whether search is enabled."""
    return render_template('index.html', search_enabled=SEARCH_ENABLED)

@app.post('/api/research')
def api_research():
    try:
        payload = request.get_json(silent=True) or {}
        mode = payload.get('mode')
        if mode not in ('urls', 'topic'):
            return json_error('Invalid mode. Use "urls" or "topic".', 400)

        sources_data = []
        topic = None

        if mode == 'urls':
            urls = payload.get('urls', [])
            if not isinstance(urls, list) or not urls:
                return json_error('Provide a non-empty list of URLs.', 400)
            # Deduplicate and cap
            seen = set()
            deduped = []
            for u in urls:
                if not isinstance(u, str):
                    continue
                u = u.strip()
                if not u:
                    continue
                if u not in seen:
                    seen.add(u)
                    deduped.append(u)
            urls = deduped[:MAX_SOURCES]

            if not urls:
                return json_error('No valid URLs provided after deduplication.', 400)

            for url in urls:
                try:
                    if not scraper_service.is_allowed_by_robots(url):
                        logger.info(f"Blocked by robots.txt: {url}")
                        continue
                    html = scraper_service.fetch_html(url)
                    if not html:
                        continue
                    extracted = scraper_service.extract_main_content(html, url)
                    if extracted and extracted.get('text'):
                        sources_data.append(extracted)
                except Exception as e:
                    logger.exception(f"Failed to process {url}: {e}")
                    continue

            if not sources_data:
                return json_error('No usable content could be extracted from the provided URLs (may be blocked by robots.txt or empty).', 422)

            topic = payload.get('topic') or 'Custom URLs'

        elif mode == 'topic':
            if not SEARCH_ENABLED:
                return json_error('Topic search is disabled. Configure SEARCH_PROVIDER=google_cse, GOOGLE_CSE_ID and GOOGLE_API_KEY to enable.', 400)
            topic = (payload.get('topic') or '').strip()
            if not topic:
                return json_error('Provide a non-empty "topic" string.', 400)

            try:
                results = search_service.search(topic, max_results=MAX_SOURCES)
            except search_service.SearchDisabledError as e:
                return json_error(str(e), 400)
            except Exception as e:
                logger.exception(f"Search failed: {e}")
                return json_error('Search failed. Please try again later.', 502)

            for item in results:
                url = item.get('url')
                try:
                    if not scraper_service.is_allowed_by_robots(url):
                        logger.info(f"Blocked by robots.txt: {url}")
                        continue
                    html = scraper_service.fetch_html(url)
                    if not html:
                        continue
                    extracted = scraper_service.extract_main_content(html, url)
                    if extracted and extracted.get('text'):
                        # Prefer search title if extraction title missing
                        if not extracted.get('title') and item.get('title'):
                            extracted['title'] = item['title']
                        sources_data.append(extracted)
                except Exception as e:
                    logger.exception(f"Failed to process {url}: {e}")
                    continue

            if not sources_data:
                return json_error('No usable content could be extracted from search results. Try a different topic.', 422)

        # Summarization pipeline
        try:
            result = summarize_service.build_research_response(topic=topic, sources=sources_data, model_name=GEMINI_MODEL)
        except Exception as e:
            logger.exception(f"Summarization failed: {e}")
            return json_error('Summarization failed. Please try again.', 502)

        return jsonify(result)

    except Exception as e:
        logger.exception(f"Unexpected error: {e}")
        return json_error('Unexpected server error.', 500)


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=PORT, debug=True)
